import {
  Routes,
  Route,
  Link
} from "react-router-dom";

import Events from "./Pages/Events";
import Registrations from "./Pages/Registrations";

function App() {

  return (

    <>

      <nav>

        <h2>Event Enrollment Manager</h2>

        <Link to="/">Events</Link>

        {" | "}

        <Link to="/registrations">Registrations</Link>

      </nav>

      <Routes>

        <Route
          path="/"
          element={<Events />}
        />

        <Route
          path="/registrations"
          element={<Registrations />}
        />

      </Routes>

    </>

  );
}

export default App;