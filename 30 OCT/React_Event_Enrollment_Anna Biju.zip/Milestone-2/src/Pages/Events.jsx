import { useState } from "react";
import { useRegistration } from "../context/RegistrationContext";

function Events() {

  const {
    events,
    registerForEvent,
    getAvailableSeats
  } = useRegistration();

  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");

  const filteredEvents = events.filter((event) => {

    const matchesSearch = event.title
      .toLowerCase()
      .includes(search.toLowerCase());

    const matchesCategory =
      category === "All" || event.category === category;

    return matchesSearch && matchesCategory;
  });

  function handleSubmit(e) {

    e.preventDefault();

    if (!name.trim() || !email.trim()) {
      setError("Please enter both name and email.");
      return;
    }

    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (!emailPattern.test(email.trim())) {
      setError("Please enter a valid email address.");
      return;
    }

    const result = registerForEvent(selectedEvent, {
      name: name,
      email: email
    });

    if (!result.success) {
      setError(result.message);
      return;
    }

    alert(result.message);

    setName("");
    setEmail("");
    setError("");
    setSelectedEvent(null);
  }

  return (
    <div className="container">

      <h1>Upcoming Events</h1>

      <input
        type="text"
        placeholder="Search events by title..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <select
        value={category}
        onChange={(e) => setCategory(e.target.value)}
      >
        <option value="All">All Categories</option>
        <option value="Technology">Technology</option>
        <option value="Arts">Arts</option>
        <option value="Life Skills">Life Skills</option>
      </select>

      <div className="event-list">

        {filteredEvents.length > 0 ? (

          filteredEvents.map((event) => (

            <div className="event-card" key={event.id}>

              <h3>{event.title}</h3>

              <p>Category: {event.category}</p>

              <p>Date: {event.date}</p>

              <p>Time: {event.time}</p>

              <p>Total Seats: {event.capacity}</p>

              <p>
                Available Seats: {getAvailableSeats(event)}
              </p>

              <button
                disabled={getAvailableSeats(event) === 0}
                onClick={() => {
                  setSelectedEvent(event);
                  setError("");
                }}
              >
                {getAvailableSeats(event) === 0
                  ? "Fully Booked"
                  : "Register"}
              </button>

            </div>

          ))

        ) : (

          <p>No events found.</p>

        )}

      </div>

      {selectedEvent && (

        <div className="form-container">

          <h2>Event Registration</h2>

          <p>Event: {selectedEvent.title}</p>

          <form onSubmit={handleSubmit}>

            <label>Full Name:</label>

            <input
              type="text"
              placeholder="Enter your full name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />

            <label>Email Address:</label>

            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            {error && (
              <p className="error">{error}</p>
            )}

            <button type="submit">
              Submit Registration
            </button>

            <button
              type="button"
              onClick={() => {
                setSelectedEvent(null);
                setName("");
                setEmail("");
                setError("");
              }}
            >
              Close
            </button>

          </form>

        </div>

      )}

    </div>
  );
}

export default Events;