import { useRegistration } from "../context/RegistrationContext";

function Registrations() {

  const {
    registrations,
    cancelRegistration
  } = useRegistration();

  function handleCancel(id) {

    const confirmation = window.confirm(
      "Are you sure you want to cancel this registration?"
    );

    if (confirmation) {
      cancelRegistration(id);
      alert("Registration cancelled successfully!");
    }
  }

  return (

    <div className="container">

      <h1>All Registrations</h1>

      {registrations.length === 0 ? (

        <p>No registrations available.</p>

      ) : (

        <table>

          <thead>
            <tr>
              <th>Attendee Name</th>
              <th>Email</th>
              <th>Event Name</th>
              <th>Event Date</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>

            {registrations.map((registration) => (

              <tr key={registration.id}>

                <td>{registration.name}</td>

                <td>{registration.email}</td>

                <td>{registration.eventTitle}</td>

                <td>{registration.eventDate}</td>

                <td>
                  <button
                    onClick={() =>
                      handleCancel(registration.id)
                    }
                  >
                    Cancel
                  </button>
                </td>

              </tr>

            ))}

          </tbody>

        </table>

      )}

    </div>

  );
}

export default Registrations;