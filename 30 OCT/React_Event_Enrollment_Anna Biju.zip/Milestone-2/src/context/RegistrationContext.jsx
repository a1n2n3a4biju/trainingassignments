import {
  createContext,
  useContext,
  useState,
  useEffect
} from "react";

const RegistrationContext = createContext();

export function RegistrationProvider({ children }) {

  const [events] = useState([
    {
      id: "EV101",
      title: "Intro to Cloud Computing",
      category: "Technology",
      date: "10 Nov 2026",
      time: "10:00",
      capacity: 4
    },
    {
      id: "EV102",
      title: "Creative Writing Lab",
      category: "Arts",
      date: "12 Nov 2026",
      time: "14:00",
      capacity: 3
    },
    {
      id: "EV103",
      title: "Data Visualization Basics",
      category: "Technology",
      date: "14 Nov 2026",
      time: "11:00",
      capacity: 5
    },
    {
      id: "EV104",
      title: "Personal Finance Essentials",
      category: "Life Skills",
      date: "16 Nov 2026",
      time: "16:00",
      capacity: 4
    },
    {
      id: "EV105",
      title: "Public Speaking Practice",
      category: "Life Skills",
      date: "18 Nov 2026",
      time: "10:30",
      capacity: 3
    },
    {
      id: "EV106",
      title: "Digital Illustration Studio",
      category: "Arts",
      date: "20 Nov 2026",
      time: "13:00",
      capacity: 2
    }
  ]);

  const [registrations, setRegistrations] = useState(() => {
    const savedData = localStorage.getItem("registrations");
    return savedData ? JSON.parse(savedData) : [];
  });

  useEffect(() => {
    localStorage.setItem(
      "registrations",
      JSON.stringify(registrations)
    );
  }, [registrations]);

  function getAvailableSeats(event) {
    const registeredCount = registrations.filter(
      (registration) => registration.eventId === event.id
    ).length;

    return event.capacity - registeredCount;
  }

  function registerForEvent(event, details) {

    const availableSeats = getAvailableSeats(event);

    if (availableSeats <= 0) {
      return {
        success: false,
        message: "This event is fully booked."
      };
    }

    const normalizedEmail = details.email.trim().toLowerCase();

    const alreadyRegistered = registrations.some(
      (registration) =>
        registration.eventId === event.id &&
        registration.email.trim().toLowerCase() === normalizedEmail
    );

    if (alreadyRegistered) {
      return {
        success: false,
        message: "This email is already registered for this event."
      };
    }

    const newRegistration = {
      id: Date.now(),
      eventId: event.id,
      name: details.name.trim(),
      email: normalizedEmail,
      eventTitle: event.title,
      eventDate: event.date
    };

    setRegistrations((previous) => [
      ...previous,
      newRegistration
    ]);

    return {
      success: true,
      message: "Registration successful!"
    };
  }

  function cancelRegistration(id) {
    setRegistrations((previous) =>
      previous.filter(
        (registration) => registration.id !== id
      )
    );
  }

  return (
    <RegistrationContext.Provider
      value={{
        events,
        registrations,
        registerForEvent,
        cancelRegistration,
        getAvailableSeats
      }}
    >
      {children}
    </RegistrationContext.Provider>
  );
}

export function useRegistration() {
  return useContext(RegistrationContext);
}