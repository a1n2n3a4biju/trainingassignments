# Event Enrollment Manager

## Technologies Used

- React JS
- Vite
- JavaScript
- React Router
- Context API
- HTML
- CSS
- localStorage

## Features

- Display  events
- Search events by title
- Filter events by category
- Register for events
- Validate email of
- Prevent duplicate registrations
- View all registrations
- Cancel registrations
- Update available seats
- Save registrations in localStorage

## Instructions
npm create vite@latest Milestone-2 -- --template react
cd Milestone-2

## Installations

npm install
npm install react-router-dom   

## Run Application

npm run dev